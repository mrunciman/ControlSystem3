from cylmarker import load_data, save_data, keypoints
from cylmarker.pose_estimation import pose_estimation
from cylmarker.make_new_pattern_and_marker import create_new_pattern, create_new_marker
from cylmarker.pose_estimation import img_segmentation
import argparse
import cv2 as cv
from VideoCap import CameraSource
import numpy as np

def homo(R,T):
    T = T.reshape(3,-1)
    homo = np.concatenate((R, T), axis = 1)
    ones = np.array([0,0,0,1]).reshape(1,4)
    homo = np.concatenate((homo, ones), axis = 0)
    return homo

def unpack_homo(homo):
    R = homo[:,:3][:3]
    t = homo[:,-1][:3]
    return R,t


def show_sgmntd_bg_and_fg(im, mask_marker_bg, mask_marker_fg, is_show=False):
    im_copy = im.copy()
    alpha = 0.4
    # First we show the background part only
    mask_marker_bg = cv.subtract(mask_marker_bg, mask_marker_fg)
    mask_bg_blue = np.zeros_like(im_copy)
    mask_bg_blue[:,:,0] = mask_marker_bg
    im_copy = cv.addWeighted(im_copy, 1.0, mask_bg_blue, alpha, 0)
    # Then we show the foreground part
    alpha = 0.7
    mask_fg_red = np.zeros_like(im_copy)
    mask_fg_red[:,:,2] = mask_marker_fg
    im_copy = cv.addWeighted(im_copy, 1.0, mask_fg_red, alpha, 0)

    mask_marker_bg = cv.cvtColor(mask_marker_bg,cv.COLOR_GRAY2RGB)
    mask_marker_fg = cv.cvtColor(mask_marker_fg,cv.COLOR_GRAY2RGB)
    im_copy = np.concatenate((mask_marker_bg, im), axis=1)

    im_copy = cv.resize(im_copy, None, fx=0.5, fy=0.5, interpolation=cv.INTER_AREA)

    if is_show:
        cv.imshow("Segmentation | Blue: background | Red: foreground", im_copy)
        cv.waitKey(1)

    return mask_marker_bg
def show_axis(im, rvecs, tvecs, cam_matrix, dist_coeff, length, is_show=False):
    axis = np.float32([[0, 0, 0], [length,0,0], [0,length,0], [0,0,length]]).reshape(-1,3)
    imgpts, jac = cv.projectPoints(axis, rvecs, tvecs, cam_matrix, dist_coeff)
    imgpts = np.rint(imgpts).astype(int)
    frame_centre = tuple(imgpts[0].ravel())

    thickness = 4
    im = cv.line(im, frame_centre, tuple(imgpts[3].ravel()), (0,0,255), thickness, cv.LINE_AA)#R 3 Z
    im = cv.line(im, frame_centre, tuple(imgpts[2].ravel()), (0,255,0), thickness, cv.LINE_AA)#G 2 Y
    im = cv.line(im, frame_centre, tuple(imgpts[1].ravel()), (255,0,0), thickness, cv.LINE_AA)#B 1 X

    if is_show:
        cv.imshow("image", im)
        cv.waitKey(1)

    return im


class PoseEstimator:
    def __init__(self, config_path):
        self.config_path = config_path

    def initialize(self,from_matlab):
        self.config_file_data, cam_calib_data = load_data.load_config_and_cam_calib_data(self.config_path)
        self.data_pttrn, self.data_marker = load_data.load_pttrn_and_marker_data(self.config_path)
        self.camera = CameraSource(self.config_file_data['cam_idx'],self.config_file_data['width'],self.config_file_data['height'])
        self.camera.initialize()
        ## Load pattern data
        self.sqnc_max_ind = len(self.data_pttrn) - 1
        self.sequence_length = len(self.data_pttrn['sequence_0']['code']) # TODO: hardcoded
        ## Load camera matrix and distortion coefficients
        cam_matrix = cam_calib_data['camera_matrix']['data']
        self.cam_matrix = np.reshape(cam_matrix, (3, 3))
        dist_coeff_data = cam_calib_data['dist_coeff']['data']
        self.dist_coeff = np.array(dist_coeff_data)

        translation_path = self.data_pttrn['translation_path']
        if from_matlab:
            from scipy import io
            mat_path = translation_path+'XY.mat'
            mat = io.loadmat(mat_path)
            self.X = mat['X1']
            self.Y = mat['Y1']
        else:
            XY = np.load(translation_path+'XY.npy',allow_pickle=True).item()
            self.X = XY['X']
            self.Y = XY['Y']

        
    def stop(self):
        self.camera.end()

    def pose_estimate(self,is_show=False):
        im = self.camera.receive_img()

        im = cv.undistort(im, self.cam_matrix, self.dist_coeff)
        dist_coeff = None # we don't need to undistort again

        """ Step II - Segment the marker and detect features """
        mask_marker_bg, mask_marker_fg = img_segmentation.marker_segmentation(im, self.config_file_data)

        # Draw segmented background and foreground
        mask_marker_bg = show_sgmntd_bg_and_fg(im, mask_marker_bg, mask_marker_fg)
        """ Step III - Identify features """
        pttrn = keypoints.find_keypoints(im, mask_marker_fg, self.config_file_data, self.sqnc_max_ind, self.sequence_length, self.data_pttrn, self.data_marker)
        # Estimate pose
        if pttrn is not None:
            # Draw contours and lines (for visualization)
            # show_contours_and_lines_and_centroids(im, pttrn)
            pnts_3d_object, pnts_2d_image = pttrn.get_data_for_pnp_solver()
            #save_pts_info(im_path, pnts_3d_object, pnts_2d_image)
            """ Step IV - Estimate the marker's pose """
            valid, rvec_pred, tvec_pred, inliers = cv.solvePnPRansac(pnts_3d_object, pnts_2d_image, self.cam_matrix, dist_coeff, None, None, False, 1000, 3.0, 0.9999, None, cv.SOLVEPNP_EPNP)
            # valid, rvec_pred, tvec_pred, inliers = cv.solvePnPRansac(pnts_3d_object, pnts_2d_image, cam_matrix, dist_coeff, None, None, False, 1000, 3.0, 0.9999, None, cv.SOLVEPNP_SQPNP)
            if valid:
                im = show_axis(im, rvec_pred, tvec_pred, self.cam_matrix, dist_coeff, 6, is_show)
            return homo(rvec_pred,tvec_pred)
        else:
            print("none pattern detected")
            if is_show:
                cv.imshow("image", mask_marker_bg)
                cv.waitKey(1)
            return None
    def send_pose(self):
        h1 = self.pose_estimate()
        if h1 is not None:
            temp1 = np.dot(np.dot(np.linalg.inv(self.Y),h1),self.X)
            return temp1
        else:
            return None

